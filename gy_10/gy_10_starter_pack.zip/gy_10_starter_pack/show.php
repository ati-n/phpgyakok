<?php
    // töltsd be az adott TAJ számú embert, ha létezik
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adatok</title>
</head>
<body>
    Teljes név: <br>
    E-mail: <br>
    TAJ szám: <br>
    Életkor:  <br>
    Nem: <br>
    Regisztráció dátuma: <br>
    Megjegyzés:  <br>
    <a href="delete.php PARAMÉTEREZD">Törlés</a> <br>
    <a href="index.php">Vissza a kezdőlapra</a>
</body>
</html>
