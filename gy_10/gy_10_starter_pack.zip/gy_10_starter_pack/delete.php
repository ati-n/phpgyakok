<?php
    // itt nem kell HTML kimenet, csak HA KELL (!!!) csinálja meg a dolgát és irányítson el mindig
?>
